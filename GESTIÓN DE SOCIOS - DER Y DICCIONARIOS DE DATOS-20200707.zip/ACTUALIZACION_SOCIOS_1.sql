--configuraciones
Insert into FN_CONFIGURACIONES (EDAD_MIN_SOCIO,CONC_IVA_10_VENTA,CONC_IVA_5_VENTA,ULT_NUM_FACT_VTA,ULT_NUM_RECIBO,COSTO_IMP_CARNET)
values ('1','6','7','001-001-0000340','001-001-0015010','20000');
--sc_categoria
update sc_categoria set edad_desde=1 where cod_categ=1;
--fn_documentos
Update fn_documentos set nro_documento='001-001-0000310' where clave_doc=11; 
Update fn_documentos set nro_documento='001-001-0015009' where clave_doc=31; 
Update fn_documentos set nro_documento='001-001-0015010' where clave_doc=32; 
--ad_entradas
update ad_entradas a set num_socio=3 where id_entrada='25' and id_evento='1';
update ad_entradas a set num_socio=4 where id_entrada='38' and id_evento='1';
update ad_entradas a set num_socio=5 where id_entrada='39' and id_evento='1';
update ad_entradas a set num_socio=7 where id_entrada='40' and id_evento='1';
update ad_entradas a set num_socio=13 where id_entrada='41' and id_evento='1';
update ad_entradas a set num_socio=15 where id_entrada='78' and id_evento='1';
update ad_entradas a set num_socio=20 where id_entrada='79' and id_evento='1';
update ad_entradas a set num_socio=21 where id_entrada='80' and id_evento='1';
update ad_entradas a set num_socio=22 where id_entrada='81' and id_evento='1';
update ad_entradas a set num_socio=13 where id_entrada='600' and id_evento='2';
update ad_entradas a set num_socio=14 where id_entrada='500' and id_evento='2';
update ad_entradas a set num_socio=19 where id_entrada='200' and id_evento='2';
update ad_entradas a set num_socio=21 where id_entrada='300' and id_evento='2' ;
update ad_entradas a set num_socio=16 where id_entrada='600' and id_evento='5' ;
update ad_entradas a set num_socio=7 where id_entrada='500' and id_evento='5' ;
update ad_entradas a set num_socio=8 where id_entrada='600' and id_evento='6' ;
update ad_entradas a set num_socio=9 where id_entrada='500' and id_evento='6' ;
update ad_entradas a set num_socio=1 where id_entrada='100' and id_evento='7' ;
update ad_entradas a set num_socio=5 where id_entrada='200' and id_evento='7' ;
update ad_entradas a set num_socio=17 where id_entrada='600' and id_evento='7' ;
update ad_entradas a set num_socio=19 where id_entrada='500' and id_evento='7' ;
update ad_entradas a set num_socio=21 where id_entrada='300' and id_evento='7' ;
update ad_entradas a set num_socio=11 where id_entrada='500' and id_evento='8' ;
--actualizar entradas generadas
update ad_entradas  set Num_socio = null, fecha_entrega = null where id_entrada=600 and id_evento=6;
update ad_entradas  set Num_socio = null, fecha_entrega = null where id_entrada=100 and id_evento=8;
update ad_entradas  set Num_socio = null, fecha_entrega = null where id_entrada=200 and id_evento=8;
update ad_entradas  set Num_socio = null, fecha_entrega = null where id_entrada=600 and id_evento=8;
--fn_documentos
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('33','001-001-0000318','1','3',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('34','001-001-0000319','1','4',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('35','001-001-0000320','1','5',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('36','001-001-0000321','1','7',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'25000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('37','001-001-0000322','1','13',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'25000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('38','001-001-0000323','1','15',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'20000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('39','001-001-0000324','1','20',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'20000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('40','001-001-0000325','1','21',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'20000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('41','001-001-0000326','1','22',to_date('25/2/19','fmDD/MM/RR'),'1','daca',to_date('25/2/19','fmDD/MM/RR'),null,'20000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('42','001-001-0000327','1','13',to_date('7/3/19','fmDD/MM/RR'),'1','daca',to_date('7/3/19','fmDD/MM/RR'),null,'20000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('43','001-001-0000328','1','14',to_date('7/3/19','fmDD/MM/RR'),'1','daca',to_date('7/3/19','fmDD/MM/RR'),null,'15000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('44','001-001-0000329','1','19',to_date('7/3/19','fmDD/MM/RR'),'1','daca',to_date('7/3/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('45','001-001-0000330','1','21',to_date('7/3/19','fmDD/MM/RR'),'1','daca',to_date('7/3/19','fmDD/MM/RR'),null,'20000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('46','001-001-0000331','1','7',to_date('28/6/19','fmDD/MM/RR'),'1','daca',to_date('28/6/19','fmDD/MM/RR'),null,'15000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('47','001-001-0000332','1','16',to_date('28/6/19','fmDD/MM/RR'),'1','daca',to_date('28/6/19','fmDD/MM/RR'),null,'20000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('48','001-001-0000333','1','8',to_date('28/7/19','fmDD/MM/RR'),'1','daca',to_date('28/7/19','fmDD/MM/RR'),null,'20000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('49','001-001-0000334','1','9',to_date('28/7/19','fmDD/MM/RR'),'1','daca',to_date('28/7/19','fmDD/MM/RR'),null,'15000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('50','001-001-0000335','1','1',to_date('28/9/19','fmDD/MM/RR'),'1','daca',to_date('28/9/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('51','001-001-0000336','1','1',to_date('28/9/19','fmDD/MM/RR'),'1','daca',to_date('28/9/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('52','001-001-0000337','1','1',to_date('28/9/19','fmDD/MM/RR'),'1','daca',to_date('28/9/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('53','001-001-0000338','1','1',to_date('28/9/19','fmDD/MM/RR'),'1','daca',to_date('28/9/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('54','001-001-0000339','1','1',to_date('28/9/19','fmDD/MM/RR'),'1','daca',to_date('28/9/19','fmDD/MM/RR'),null,'30000');
Insert into FN_DOCUMENTOS (CLAVE_DOC,NRO_DOCUMENTO,NUM_CAJA_CTA,NUM_SOCIO,FEC_EMISION,COD_TIPODOC,USUARIO_CARGA,FEC_CARGA,OBSERVACIONES,TOTAL_DOC) values ('55','001-001-0000340','1','1',to_date('10/10/19','fmDD/MM/RR'),'1','daca',to_date('10/10/19','fmDD/MM/RR'),null,'15000');
--fn_documentos_det
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('33','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('34','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('35','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('36','1','25000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('37','1','25000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('38','1','20000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('39','1','20000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('40','1','20000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('41','1','20000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('42','1','20000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('43','1','15000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('44','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('45','1','20000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('46','1','15000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('47','1','20000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('48','1','20000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('49','1','15000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('50','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('51','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('52','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('53','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('54','1','30000','0','0','8');
Insert into FN_DOCUMENTOS_DET (CLAVE_DOC,NUM_ITEM,EXENTAS,IVA,GRAVADA,COD_CONCEPTO) values ('55','1','15000','0','0','8');

commit;



